Todo List
==========

Test the code with logic analyser

Remove all references to old MPU9150 code

Find documentation for DMP registers and Free Fall registers

Add wiring diagrams

Add SPI support

Make referenceing the Magnetometer easier to use and possibly merge with Accelerometer/Gyrometer register reference functions